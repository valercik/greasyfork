# Out of band cache refresh

ScriptsController.get_by_sites({force: true})
