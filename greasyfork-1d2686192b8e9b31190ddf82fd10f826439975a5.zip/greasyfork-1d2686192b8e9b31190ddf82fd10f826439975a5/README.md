[Greasy Fork](https://greasyfork.org) is an online repository of user scripts.

## Help

Post in the [Greasy Forum](https://greasyfork.org/forum/) for help with Greasy Fork, user scripts, user script managers, or related.

## Contributing

[![Build Status](https://travis-ci.org/JasonBarnabe/greasyfork.svg?branch=master)](https://travis-ci.org/JasonBarnabe/greasyfork)

Greasy Fork welcomes contributions. Learn about [running Greasy Fork locally](https://github.com/JasonBarnabe/greasyfork/wiki/Running-Greasy-Fork-locally) and [contributing code](https://github.com/JasonBarnabe/greasyfork/wiki/Contributing-code).

## Donations

If you like Greasy Fork, consider making a donation to help pay for hosting. Suggested amount is $10.

* [Donate by PayPal or credit card](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=jason.barnabe@gmail.com&item_name=Contribution+for+Greasy+Fork)

## License

Greasy Fork is licensed under the [GPLv3](https://github.com/JasonBarnabe/greasyfork/blob/master/COPYING).
