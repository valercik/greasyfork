class ScriptSyncSource < ApplicationRecord
end
