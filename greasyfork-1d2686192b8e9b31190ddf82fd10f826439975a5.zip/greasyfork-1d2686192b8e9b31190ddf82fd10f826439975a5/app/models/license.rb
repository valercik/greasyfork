class License < ApplicationRecord

end
