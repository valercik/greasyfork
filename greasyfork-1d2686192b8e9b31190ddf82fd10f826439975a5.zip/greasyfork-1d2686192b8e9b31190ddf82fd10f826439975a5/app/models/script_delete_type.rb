class ScriptDeleteType < ApplicationRecord
end
