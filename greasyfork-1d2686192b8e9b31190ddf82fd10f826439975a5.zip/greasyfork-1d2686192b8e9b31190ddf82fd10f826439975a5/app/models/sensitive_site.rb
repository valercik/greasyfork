class SensitiveSite < ApplicationRecord
end
