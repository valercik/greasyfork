class Browser < ApplicationRecord
end
