class SpammyEmailDomain < ApplicationRecord
end
