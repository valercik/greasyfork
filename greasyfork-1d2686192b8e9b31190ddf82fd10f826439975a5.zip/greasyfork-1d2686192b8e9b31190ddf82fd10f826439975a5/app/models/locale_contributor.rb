class LocaleContributor < ApplicationRecord
	belongs_to :locale
end
