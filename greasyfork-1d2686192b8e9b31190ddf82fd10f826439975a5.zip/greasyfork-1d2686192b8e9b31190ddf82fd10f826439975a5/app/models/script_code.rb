class ScriptCode < ApplicationRecord
end
