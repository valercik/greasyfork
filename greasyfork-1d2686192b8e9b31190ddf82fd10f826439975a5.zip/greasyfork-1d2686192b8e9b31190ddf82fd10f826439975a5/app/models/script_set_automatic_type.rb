class ScriptSetAutomaticType < ApplicationRecord
end
