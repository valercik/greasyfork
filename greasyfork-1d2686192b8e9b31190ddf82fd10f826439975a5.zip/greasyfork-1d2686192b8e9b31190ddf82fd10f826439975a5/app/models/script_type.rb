class ScriptType < ApplicationRecord
end
