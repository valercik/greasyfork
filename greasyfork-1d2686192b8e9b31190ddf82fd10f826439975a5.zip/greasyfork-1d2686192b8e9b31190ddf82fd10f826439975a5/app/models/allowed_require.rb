class AllowedRequire < ApplicationRecord

	def readonly?
		true
	end

end
