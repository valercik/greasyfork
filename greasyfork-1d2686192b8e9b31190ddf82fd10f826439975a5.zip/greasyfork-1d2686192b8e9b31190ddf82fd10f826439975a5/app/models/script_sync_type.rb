class ScriptSyncType < ApplicationRecord
end
