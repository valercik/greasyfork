class CpdDuplicationScript < ApplicationRecord
	belongs_to :cpd_duplication
	belongs_to :script
end
