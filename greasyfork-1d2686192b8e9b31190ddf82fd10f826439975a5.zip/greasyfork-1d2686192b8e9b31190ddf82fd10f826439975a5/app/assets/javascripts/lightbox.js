document.addEventListener("DOMContentLoaded", function(event) {
	var lightbox = new Lightbox();
	lightbox.load();
});
