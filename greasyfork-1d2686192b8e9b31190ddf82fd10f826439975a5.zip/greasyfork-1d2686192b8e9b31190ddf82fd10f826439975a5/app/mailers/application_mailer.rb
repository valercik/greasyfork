class ApplicationMailer < ActionMailer::Base
  default from: 'noreply@greasyfork.org'
end