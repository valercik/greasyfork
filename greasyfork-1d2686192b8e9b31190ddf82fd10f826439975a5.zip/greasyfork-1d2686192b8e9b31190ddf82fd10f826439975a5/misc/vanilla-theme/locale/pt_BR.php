<?php
$Definition['layouts.application.script_list'] = 'Scripts';
$Definition['layouts.application.forum'] = 'Fórum';
$Definition['layouts.application.help'] = 'Ajuda';
$Definition['layouts.application.submenu'] = 'Mais';
$Definition['layouts.application.advanced_search'] = 'Pesquisa avançada';
$Definition['layouts.application.user_list'] = 'Lista de usuários';
$Definition['layouts.application.libraries'] = 'Bibliotecas';
$Definition['layouts.application.moderator_log'] = 'Registros de moderador';
