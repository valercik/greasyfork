<?php
$Definition['layouts.application.script_list'] = '脚本列表';
$Definition['layouts.application.forum'] = '论坛';
$Definition['layouts.application.help'] = '站点帮助';
$Definition['layouts.application.submenu'] = '更多';
$Definition['layouts.application.advanced_search'] = '高级搜索';
$Definition['layouts.application.user_list'] = '用户列表';
$Definition['layouts.application.libraries'] = '库';
$Definition['layouts.application.moderator_log'] = '管理日志';
