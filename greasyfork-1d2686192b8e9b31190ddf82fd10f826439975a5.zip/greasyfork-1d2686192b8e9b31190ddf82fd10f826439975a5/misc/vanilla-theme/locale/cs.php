<?php
$Definition['layouts.application.script_list'] = 'Skripty';
$Definition['layouts.application.forum'] = 'Fórum';
$Definition['layouts.application.help'] = 'Nápověda';
$Definition['layouts.application.submenu'] = 'Více';
$Definition['layouts.application.advanced_search'] = 'Pokročilé hledání';
$Definition['layouts.application.user_list'] = 'Seznam uživatelů';
$Definition['layouts.application.libraries'] = 'Knihovny';
$Definition['layouts.application.moderator_log'] = 'Záznamy moderátora';
