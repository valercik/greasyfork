<?php
$Definition['layouts.application.script_list'] = 'Scripts';
$Definition['layouts.application.forum'] = 'Foro';
$Definition['layouts.application.help'] = 'Ayuda';
$Definition['layouts.application.submenu'] = 'Más';
$Definition['layouts.application.advanced_search'] = 'Búsqueda avanzada';
$Definition['layouts.application.user_list'] = 'Listado de usuarios';
$Definition['layouts.application.libraries'] = 'Bibliotecas';
$Definition['layouts.application.moderator_log'] = 'Registro del moderador';
