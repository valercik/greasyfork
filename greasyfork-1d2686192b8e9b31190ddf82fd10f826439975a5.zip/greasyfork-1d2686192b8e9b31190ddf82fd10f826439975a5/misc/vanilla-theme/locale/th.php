<?php
$Definition['layouts.application.script_list'] = 'สคริปต์';
$Definition['layouts.application.forum'] = 'ฟอรัม';
$Definition['layouts.application.help'] = 'ช่วยเหลือ';
$Definition['layouts.application.submenu'] = 'อื่น ๆ';
$Definition['layouts.application.advanced_search'] = 'การค้นหาขั้นสูง';
$Definition['layouts.application.user_list'] = 'รายชื่อผู้ใช้';
$Definition['layouts.application.libraries'] = 'คลัง';
$Definition['layouts.application.moderator_log'] = 'บันทึกผู้ช่วยดูแล';
