<?php
$Definition['layouts.application.script_list'] = 'Κώδικες';
$Definition['layouts.application.forum'] = 'Δημόσια Συζήτηση';
$Definition['layouts.application.help'] = 'Βοήθεια';
$Definition['layouts.application.submenu'] = 'Περισσότερα';
$Definition['layouts.application.advanced_search'] = 'Αναζήτηση για προχωρημένους';
$Definition['layouts.application.user_list'] = 'Λίστα χρηστών';
$Definition['layouts.application.libraries'] = 'Βιβλιοθήκες';
$Definition['layouts.application.moderator_log'] = 'Καταγραφή διαχειριστών';
