<?php
$Definition['layouts.application.script_list'] = 'סקריפטים';
$Definition['layouts.application.forum'] = 'פורום';
$Definition['layouts.application.help'] = 'עזרה';
$Definition['layouts.application.submenu'] = 'עוד';
$Definition['layouts.application.advanced_search'] = 'חיפוש מתקדם';
$Definition['layouts.application.user_list'] = 'רשימת משתמש';
$Definition['layouts.application.libraries'] = 'ספריות';
$Definition['layouts.application.moderator_log'] = 'Moderator log';
