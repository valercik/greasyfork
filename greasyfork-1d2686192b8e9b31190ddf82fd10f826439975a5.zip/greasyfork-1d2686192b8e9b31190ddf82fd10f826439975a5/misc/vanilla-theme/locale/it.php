<?php
$Definition['layouts.application.script_list'] = 'Script';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Aiuto';
$Definition['layouts.application.submenu'] = 'Altro';
$Definition['layouts.application.advanced_search'] = 'Ricerca avanzata';
$Definition['layouts.application.user_list'] = 'Lista utente';
$Definition['layouts.application.libraries'] = 'Librerie';
$Definition['layouts.application.moderator_log'] = 'Log moderatore';
