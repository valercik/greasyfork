<?php
$Definition['layouts.application.script_list'] = 'Scriptler';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Yardım';
$Definition['layouts.application.submenu'] = 'Daha fazla';
$Definition['layouts.application.advanced_search'] = 'Gelişmiş arama';
$Definition['layouts.application.user_list'] = 'Kullanıcı listesi';
$Definition['layouts.application.libraries'] = 'Kütüphaneler';
$Definition['layouts.application.moderator_log'] = 'Denetleyici günlüğü';
