<?php
$Definition['layouts.application.script_list'] = 'Скрипты';
$Definition['layouts.application.forum'] = 'Форум';
$Definition['layouts.application.help'] = 'Помощь';
$Definition['layouts.application.submenu'] = 'Ещё';
$Definition['layouts.application.advanced_search'] = 'Расширенный поиск';
$Definition['layouts.application.user_list'] = 'Пользователи';
$Definition['layouts.application.libraries'] = 'Библиотеки';
$Definition['layouts.application.moderator_log'] = 'Действия модераторов';
