<?php
$Definition['layouts.application.script_list'] = 'Scripts';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Hulp';
$Definition['layouts.application.submenu'] = 'Meer';
$Definition['layouts.application.advanced_search'] = 'Geavanceerd zoeken';
$Definition['layouts.application.user_list'] = 'Gebruikerslijst';
$Definition['layouts.application.libraries'] = 'Bibliotheken';
$Definition['layouts.application.moderator_log'] = 'Moderator log';
