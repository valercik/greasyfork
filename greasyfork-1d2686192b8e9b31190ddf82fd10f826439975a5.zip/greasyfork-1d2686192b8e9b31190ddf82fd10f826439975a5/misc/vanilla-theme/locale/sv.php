<?php
$Definition['layouts.application.script_list'] = 'Skript';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Hjälp';
$Definition['layouts.application.submenu'] = 'Mer';
$Definition['layouts.application.advanced_search'] = 'Avancerad sökning';
$Definition['layouts.application.user_list'] = 'Användarlista';
$Definition['layouts.application.libraries'] = 'Bibliotek';
$Definition['layouts.application.moderator_log'] = 'Moderatorlogg';
