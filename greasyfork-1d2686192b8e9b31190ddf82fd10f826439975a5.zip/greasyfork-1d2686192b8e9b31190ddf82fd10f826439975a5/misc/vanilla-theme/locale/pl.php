<?php
$Definition['layouts.application.script_list'] = 'Skrypty';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Pomoc';
$Definition['layouts.application.submenu'] = 'Więcej';
$Definition['layouts.application.advanced_search'] = 'Wyszukiwanie zaawansowane';
$Definition['layouts.application.user_list'] = 'Lista użytkowników';
$Definition['layouts.application.libraries'] = 'Biblioteki';
$Definition['layouts.application.moderator_log'] = 'Log moderatora';
