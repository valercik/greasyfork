<?php
$Definition['layouts.application.script_list'] = 'Skrip';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Bantuan';
$Definition['layouts.application.submenu'] = 'Lainnya';
$Definition['layouts.application.advanced_search'] = 'Pencarian Lanjutan';
$Definition['layouts.application.user_list'] = 'Daftar Pengguna';
$Definition['layouts.application.libraries'] = 'Pustaka';
$Definition['layouts.application.moderator_log'] = 'Riwayat moderator';
