<?php
$Definition['layouts.application.script_list'] = 'Scripturi';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Ajutor';
$Definition['layouts.application.submenu'] = 'Mai mult';
$Definition['layouts.application.advanced_search'] = 'Căutare avansată';
$Definition['layouts.application.user_list'] = 'Lista utilizatorilor';
$Definition['layouts.application.libraries'] = 'Biblioteci';
$Definition['layouts.application.moderator_log'] = 'Jurnalul moderatorului';
