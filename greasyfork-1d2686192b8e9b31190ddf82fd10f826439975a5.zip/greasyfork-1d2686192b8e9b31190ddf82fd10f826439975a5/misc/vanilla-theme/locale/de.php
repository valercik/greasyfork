<?php
$Definition['layouts.application.script_list'] = 'Skripte';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Hilfe';
$Definition['layouts.application.submenu'] = 'mehr';
$Definition['layouts.application.advanced_search'] = 'Erweiterte Suche';
$Definition['layouts.application.user_list'] = 'Benutzerliste';
$Definition['layouts.application.libraries'] = 'Bibliotheken';
$Definition['layouts.application.moderator_log'] = 'Moderator Protokoll';
