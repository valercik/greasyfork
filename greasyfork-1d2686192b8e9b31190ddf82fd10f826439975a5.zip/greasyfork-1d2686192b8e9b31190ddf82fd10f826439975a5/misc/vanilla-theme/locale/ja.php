<?php
$Definition['layouts.application.script_list'] = 'スクリプト';
$Definition['layouts.application.forum'] = '掲示板';
$Definition['layouts.application.help'] = 'ヘルプ';
$Definition['layouts.application.submenu'] = 'その他';
$Definition['layouts.application.advanced_search'] = '検索';
$Definition['layouts.application.user_list'] = 'ユーザー一覧';
$Definition['layouts.application.libraries'] = 'ライブラリ一覧';
$Definition['layouts.application.moderator_log'] = 'モデレーターのログ';
