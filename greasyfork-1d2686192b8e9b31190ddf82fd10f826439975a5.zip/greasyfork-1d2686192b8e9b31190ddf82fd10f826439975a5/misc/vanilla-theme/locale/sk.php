<?php
$Definition['layouts.application.script_list'] = 'Skripty';
$Definition['layouts.application.forum'] = 'Fórum';
$Definition['layouts.application.help'] = 'Pomocník';
$Definition['layouts.application.submenu'] = 'Viac';
$Definition['layouts.application.advanced_search'] = 'Pokročilé vyhľadávanie';
$Definition['layouts.application.user_list'] = 'Zoznam užívateľov';
$Definition['layouts.application.libraries'] = 'Knižnice';
$Definition['layouts.application.moderator_log'] = 'Záznam moderátora';
