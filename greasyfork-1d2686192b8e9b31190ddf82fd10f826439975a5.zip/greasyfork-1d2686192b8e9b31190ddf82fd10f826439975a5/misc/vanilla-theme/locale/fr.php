<?php
$Definition['layouts.application.script_list'] = 'Scripts';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Aide';
$Definition['layouts.application.submenu'] = 'Plus';
$Definition['layouts.application.advanced_search'] = 'Recherche avancée';
$Definition['layouts.application.user_list'] = 'Liste d\'utilisateurs';
$Definition['layouts.application.libraries'] = 'Bibliothèques';
$Definition['layouts.application.moderator_log'] = 'Log modérateur';
