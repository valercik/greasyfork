<?php
$Definition['layouts.application.script_list'] = 'Scripts';
$Definition['layouts.application.forum'] = 'Forum';
$Definition['layouts.application.help'] = 'Aide';
$Definition['layouts.application.submenu'] = 'More';
$Definition['layouts.application.advanced_search'] = 'Advanced search';
$Definition['layouts.application.user_list'] = 'User list';
$Definition['layouts.application.libraries'] = 'Libraries';
$Definition['layouts.application.moderator_log'] = 'Moderator log';
