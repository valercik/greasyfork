<?php
$Definition['layouts.application.script_list'] = 'Скрипти';
$Definition['layouts.application.forum'] = 'Форум';
$Definition['layouts.application.help'] = 'Допомога';
$Definition['layouts.application.submenu'] = 'Більше';
$Definition['layouts.application.advanced_search'] = 'Розширений пошук';
$Definition['layouts.application.user_list'] = 'Список користувача';
$Definition['layouts.application.libraries'] = 'Бібліотеки';
$Definition['layouts.application.moderator_log'] = 'Лог модератора';
