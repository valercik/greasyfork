<?php
$Definition['layouts.application.script_list'] = 'Szkriptek';
$Definition['layouts.application.forum'] = 'Fórum';
$Definition['layouts.application.help'] = 'Segítség';
$Definition['layouts.application.submenu'] = 'Továbbiak';
$Definition['layouts.application.advanced_search'] = 'Részletes keresés';
$Definition['layouts.application.user_list'] = 'Felhasználók';
$Definition['layouts.application.libraries'] = 'Könyvtárak';
$Definition['layouts.application.moderator_log'] = 'Moderátor napló';
