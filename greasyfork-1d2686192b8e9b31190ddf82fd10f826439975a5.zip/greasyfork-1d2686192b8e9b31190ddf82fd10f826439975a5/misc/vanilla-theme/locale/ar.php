<?php
$Definition['layouts.application.script_list'] = 'البرامج النصية';
$Definition['layouts.application.forum'] = 'المنتدى';
$Definition['layouts.application.help'] = 'المساعدة';
$Definition['layouts.application.submenu'] = 'أكثر';
$Definition['layouts.application.advanced_search'] = 'بحث متقدم';
$Definition['layouts.application.user_list'] = 'قائمة المستخدمين';
$Definition['layouts.application.libraries'] = 'المكتبات';
$Definition['layouts.application.moderator_log'] = 'سجل المشرف';
