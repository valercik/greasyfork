<?php
$Definition['layouts.application.script_list'] = '스크립트';
$Definition['layouts.application.forum'] = '포럼';
$Definition['layouts.application.help'] = '도움말';
$Definition['layouts.application.submenu'] = '더 보기...';
$Definition['layouts.application.advanced_search'] = '상세 검색';
$Definition['layouts.application.user_list'] = '유저 목록';
$Definition['layouts.application.libraries'] = '라이브러리';
$Definition['layouts.application.moderator_log'] = 'Moderator log';
