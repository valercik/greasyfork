<?php
$Definition['layouts.application.script_list'] = 'Скриптове';
$Definition['layouts.application.forum'] = 'Форум';
$Definition['layouts.application.help'] = 'Помощ';
$Definition['layouts.application.submenu'] = 'Още';
$Definition['layouts.application.advanced_search'] = 'Разширено търсене';
$Definition['layouts.application.user_list'] = 'Потребителски списък';
$Definition['layouts.application.libraries'] = 'Библиотеки';
$Definition['layouts.application.moderator_log'] = 'Модераторски дневник';
