<?php
$Definition['layouts.application.script_list'] = 'Scripts';
$Definition['layouts.application.forum'] = 'Diễn đàn';
$Definition['layouts.application.help'] = 'Hướng dẫn';
$Definition['layouts.application.submenu'] = 'Thêm';
$Definition['layouts.application.advanced_search'] = 'TÌm kiếm nâng cao';
$Definition['layouts.application.user_list'] = 'Danh sách người dùng';
$Definition['layouts.application.libraries'] = 'Các thư viện';
$Definition['layouts.application.moderator_log'] = 'Nhật ký điều hành';
