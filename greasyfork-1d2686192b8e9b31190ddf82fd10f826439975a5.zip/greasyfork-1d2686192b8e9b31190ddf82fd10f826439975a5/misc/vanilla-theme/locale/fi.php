<?php
$Definition['layouts.application.script_list'] = 'Skriptit';
$Definition['layouts.application.forum'] = 'Foorumi';
$Definition['layouts.application.help'] = 'Ohje';
$Definition['layouts.application.submenu'] = 'More';
$Definition['layouts.application.advanced_search'] = 'Advanced search';
$Definition['layouts.application.user_list'] = 'User list';
$Definition['layouts.application.libraries'] = 'Libraries';
$Definition['layouts.application.moderator_log'] = 'Moderator log';
