<?php
$Definition['layouts.application.script_list'] = '腳本列表';
$Definition['layouts.application.forum'] = '論壇';
$Definition['layouts.application.help'] = '說明文件';
$Definition['layouts.application.submenu'] = '更多';
$Definition['layouts.application.advanced_search'] = '進階搜尋';
$Definition['layouts.application.user_list'] = '使用者列表';
$Definition['layouts.application.libraries'] = '函式庫';
$Definition['layouts.application.moderator_log'] = '管理員操作記錄';
