server "45.33.37.174", user: "deploy", roles: %w{app db web}
