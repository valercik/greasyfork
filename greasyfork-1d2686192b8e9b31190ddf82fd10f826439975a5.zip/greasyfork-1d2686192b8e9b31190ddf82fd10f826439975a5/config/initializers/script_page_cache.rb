Rails.application.config.script_page_cache_directory = Rails.root.join('tmp', 'cached_pages')
Rails.application.config.script_page_cache_expiry = 15.minutes
