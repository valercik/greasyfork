ThinkingSphinx::Connection.persistent = false
