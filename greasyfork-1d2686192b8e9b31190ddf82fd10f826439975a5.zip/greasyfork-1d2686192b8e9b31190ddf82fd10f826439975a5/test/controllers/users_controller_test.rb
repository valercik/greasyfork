require 'test_helper'

class UsersControllerTest < ActionController::TestCase

end
