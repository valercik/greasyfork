require 'test_helper'

class ScriptsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
