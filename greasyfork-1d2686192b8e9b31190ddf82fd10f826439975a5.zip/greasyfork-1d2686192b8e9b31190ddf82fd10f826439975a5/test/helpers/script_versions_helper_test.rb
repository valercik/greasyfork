require 'test_helper'

class ScriptVersionsHelperTest < ActionView::TestCase
end
