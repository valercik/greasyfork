require 'test_helper'

class HelpHelperTest < ActionView::TestCase
end
