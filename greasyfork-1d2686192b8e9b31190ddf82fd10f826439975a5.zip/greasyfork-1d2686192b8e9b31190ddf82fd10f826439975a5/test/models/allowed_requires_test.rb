require 'test_helper'

class AllowedRequiresTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
